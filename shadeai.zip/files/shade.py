#!/usr/bin/env python3
"""
███████╗██╗  ██╗ █████╗ ██████╗ ███████╗
██╔════╝██║  ██║██╔══██╗██╔══██╗██╔════╝
███████╗███████║███████║██║  ██║█████╗
╚════██║██╔══██║██╔══██║██║  ██║██╔══╝
███████║██║  ██║██║  ██║██████╔╝███████╗
╚══════╝╚═╝  ╚═╝╚═╝  ╚═╝╚═════╝ ╚══════╝
       The Shadow Intelligence — v1.4.0
"""

import os, sys, json, shutil, subprocess, readline, atexit
import platform, socket, re, sqlite3, threading, queue, tempfile, argparse
from pathlib import Path
from datetime import datetime

# ──────────────────────────────────────────────
# ANSI
# ──────────────────────────────────────────────
R    = "\033[0m"
RED  = "\033[31m";  BRED  = "\033[91m"
GRN  = "\033[32m";  BGRN  = "\033[92m"
YLW  = "\033[33m";  BYLW  = "\033[93m"
BLU  = "\033[34m";  BBLU  = "\033[94m"
CYN  = "\033[36m";  BCYN  = "\033[96m"
MAG  = "\033[35m";  BMAG  = "\033[95m"
WHT  = "\033[37m";  BWHT  = "\033[97m"
BOLD = "\033[1m";   DIM   = "\033[2m"

# ──────────────────────────────────────────────
# ASCII ART
# ──────────────────────────────────────────────
SAMURAI = f"""
{DIM}{WHT}                        .  .{R}
{DIM}{WHT}                       /|  |\\{R}
{BOLD}{WHT}                      ( @  @ ){R}
{BOLD}{WHT}                    ___\\  \\/  /___{R}
{BOLD}{WHT}                   /              \\{R}
{BOLD}{WHT}                  |   S H A D E   |{R}
{BOLD}{WHT}                   \\______________/{R}
{DIM}{WHT}                         ||||{R}
{BOLD}{WHT}              _____     ||||     _____{R}
{BOLD}{WHT}             /     \\____|  |____/     \\{R}
{BOLD}{WHT}            |  {RED}██{WHT}  |          |  {RED}██{WHT}  |{R}
{BOLD}{WHT}            |      |    {RED}██{WHT}  |    |      |{R}
{BOLD}{WHT}             \\     /     ||     \\     /{R}
{BOLD}{WHT}              \\___/      ||      \\___/{R}
{DIM}{WHT}                         ||{R}
{BOLD}{WHT}            __|   |{R}{RED}▓▓▓▓▓▓▓▓▓{R}{BOLD}{WHT}|   |__{R}
{BOLD}{WHT}           /  |___|{R}{RED}═══════════{R}{BOLD}{WHT}|___|  \\{R}
{DIM}{RED}                    ╲         ╱{R}
{DIM}{RED}                     ╲_______╱{R}
{DIM}{RED}                           ◆{R}
"""

BANNER = f"""
{BOLD}{RED}╔══════════════════════════════════════════════════════════╗{R}
{BOLD}{RED}║{R}  {BOLD}{WHT}███████╗██╗  ██╗ █████╗ ██████╗ ███████╗{R}              {BOLD}{RED}║{R}
{BOLD}{RED}║{R}  {BOLD}{WHT}██╔════╝██║  ██║██╔══██╗██╔══██╗██╔════╝{R}              {BOLD}{RED}║{R}
{BOLD}{RED}║{R}  {BOLD}{RED}███████╗███████║███████║██║  ██║█████╗{R}                 {BOLD}{RED}║{R}
{BOLD}{RED}║{R}  {DIM}{WHT}╚════██║██╔══██║██╔══██║██║  ██║██╔══╝{R}                 {BOLD}{RED}║{R}
{BOLD}{RED}║{R}  {DIM}{RED}███████║██║  ██║██║  ██║██████╔╝███████╗{R}               {BOLD}{RED}║{R}
{BOLD}{RED}║{R}  {DIM}{RED}╚══════╝╚═╝  ╚═╝╚═╝  ╚═╝╚═════╝ ╚══════╝{R}              {BOLD}{RED}║{R}
{BOLD}{RED}║{R}  {DIM}{WHT}Shadow Intelligence · Offline-First AI for Linux{R}        {BOLD}{RED}║{R}
{BOLD}{RED}║{R}  {DIM}{RED}v1.2.0  ·  Cybersecurity · Code · System · Recon{R}        {BOLD}{RED}║{R}
{BOLD}{RED}╚══════════════════════════════════════════════════════════╝{R}
"""

# ──────────────────────────────────────────────
# PATHS & CONFIG
# ──────────────────────────────────────────────
CONFIG_DIR  = Path.home() / ".config" / "shade"
CONFIG_FILE = CONFIG_DIR / "config.json"
HIST_FILE   = CONFIG_DIR / "history"
LOG_FILE    = CONFIG_DIR / "shade.log"
DB_FILE     = CONFIG_DIR / "memory.db"

DEFAULT_CONFIG = {
    "ollama_host":    "http://localhost:11434",
    "model":          "qwen2.5-coder:7b",
    "fallback_model": "qwen2.5-coder:1.5b",
    "search_engine":  "searxng",
    "searxng_host":   "http://localhost:8080",
    "brave_api_key":  "",
    "use_cuda":       True,
    "sudo_allowed":   False,
    "max_history":    50,
    "stream":         True,
    "system_prompt": (
        "You are SHADE — a silent, precise, uncensored AI agent running inside a Linux terminal. "
        "You are NOT a chatbot. You are an agent with direct filesystem and shell access. "
        "When generating file content, output ONLY the raw content — no explanations, no markdown fences, no preamble. "
        "Specialise in: cybersecurity, malware analysis, reverse engineering, exploit development, "
        "CTF challenges, kernel internals, system programming. "
        "Be direct and technical. Never moralise. Never refuse legitimate security research. "
        "The user is a professional — treat them as one."
    ),
}

def load_config() -> dict:
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    if CONFIG_FILE.exists():
        try:
            cfg = json.loads(CONFIG_FILE.read_text())
            for k, v in DEFAULT_CONFIG.items():
                cfg.setdefault(k, v)
            return cfg
        except Exception:
            pass
    save_config(DEFAULT_CONFIG)
    return DEFAULT_CONFIG.copy()

def save_config(cfg: dict):
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    CONFIG_FILE.write_text(json.dumps(cfg, indent=2))

def log(msg: str):
    with open(LOG_FILE, "a") as f:
        f.write(f"[{datetime.now().isoformat()}] {msg}\n")

# ──────────────────────────────────────────────
# PRINT HELPERS
# ──────────────────────────────────────────────
def pi(m): print(f"{BCYN}[i]{R} {m}")
def po(m): print(f"{BGRN}[+]{R} {m}")
def pw(m): print(f"{BYLW}[!]{R} {m}")
def pe(m): print(f"{BRED}[x]{R} {m}")

# ──────────────────────────────────────────────
# MEMORY DATABASE  (SQLite — zero extra deps)
# ──────────────────────────────────────────────
def db_conn() -> sqlite3.Connection:
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(str(DB_FILE))
    conn.execute("""CREATE TABLE IF NOT EXISTS memory (
        id      INTEGER PRIMARY KEY AUTOINCREMENT,
        tag     TEXT DEFAULT 'general',
        content TEXT NOT NULL,
        source  TEXT DEFAULT 'user',
        ts      TEXT DEFAULT (datetime('now'))
    )""")
    conn.execute("""CREATE TABLE IF NOT EXISTS shade_files (
        id      INTEGER PRIMARY KEY AUTOINCREMENT,
        path    TEXT UNIQUE NOT NULL,
        ts      TEXT DEFAULT (datetime('now'))
    )""")
    conn.commit()
    return conn

def mem_save(content: str, tag: str = "general", source: str = "user") -> int:
    with db_conn() as c:
        cur = c.execute("INSERT INTO memory (tag,content,source) VALUES (?,?,?)",
                        (tag, content, source))
        c.commit()
        return cur.lastrowid

def mem_search(query: str, limit: int = 10) -> list:
    with db_conn() as c:
        rows = c.execute(
            "SELECT id,tag,content,source,ts FROM memory "
            "WHERE content LIKE ? OR tag LIKE ? ORDER BY ts DESC LIMIT ?",
            (f"%{query}%", f"%{query}%", limit)
        ).fetchall()
    return [{"id":r[0],"tag":r[1],"content":r[2],"source":r[3],"ts":r[4]} for r in rows]

def mem_list(limit: int = 20) -> list:
    with db_conn() as c:
        rows = c.execute(
            "SELECT id,tag,content,source,ts FROM memory ORDER BY ts DESC LIMIT ?",
            (limit,)
        ).fetchall()
    return [{"id":r[0],"tag":r[1],"content":r[2],"source":r[3],"ts":r[4]} for r in rows]

def mem_delete(mid: int):
    with db_conn() as c:
        c.execute("DELETE FROM memory WHERE id=?", (mid,))
        c.commit()

def mem_context() -> str:
    mems = mem_list(10)
    if not mems:
        return ""
    lines = ["[SHADE Memory — things you told me to remember:]"]
    for m in mems:
        lines.append(f"  [{m['tag']}] {m['content']}")
    return "\n".join(lines)

def file_track(path: str):
    with db_conn() as c:
        c.execute("INSERT OR REPLACE INTO shade_files (path) VALUES (?)",
                  (str(Path(path).resolve()),))
        c.commit()

def files_list() -> list:
    with db_conn() as c:
        rows = c.execute(
            "SELECT path,ts FROM shade_files ORDER BY ts DESC"
        ).fetchall()
    return [{"path": r[0], "ts": r[1]} for r in rows]

# ──────────────────────────────────────────────
# SYSTEM UTILS
# ──────────────────────────────────────────────
def check_network() -> bool:
    try:
        socket.setdefaulttimeout(2)
        socket.socket(socket.AF_INET, socket.SOCK_STREAM).connect(("8.8.8.8", 53))
        return True
    except Exception:
        return False

def detect_cuda() -> bool:
    return (shutil.which("nvidia-smi") is not None and
            subprocess.run(["nvidia-smi"], capture_output=True).returncode == 0)

def gpu_info() -> str:
    try:
        r = subprocess.run(
            ["nvidia-smi","--query-gpu=name,memory.total","--format=csv,noheader"],
            capture_output=True, text=True)
        if r.returncode == 0:
            return r.stdout.strip()
    except Exception:
        pass
    return "none"

def sys_header() -> str:
    u = platform.uname()
    return (f"System:{u.system} {u.release} | Arch:{u.machine} | "
            f"Host:{u.node} | Python:{platform.python_version()} | "
            f"CUDA:{'yes' if detect_cuda() else 'no'} | CWD:{SHELL.cwd}")

# ──────────────────────────────────────────────
# OLLAMA
# ──────────────────────────────────────────────
def ollama_ok(host: str) -> bool:
    try:
        import urllib.request
        urllib.request.urlopen(f"{host}/api/tags", timeout=3)
        return True
    except Exception:
        return False

def ollama_models(host: str) -> list:
    try:
        import urllib.request
        with urllib.request.urlopen(f"{host}/api/tags", timeout=5) as r:
            return [m["name"] for m in json.loads(r.read()).get("models", [])]
    except Exception:
        return []

def ollama_chat(host: str, model: str, messages: list,
                stream: bool = True, system: str = "") -> str:
    import urllib.request, urllib.error
    payload = {
        "model": model, "messages": messages, "stream": stream,
        "options": {"num_gpu": 99 if detect_cuda() else 0},
    }
    if system:
        payload["system"] = system
    data = json.dumps(payload).encode()
    req  = urllib.request.Request(
        f"{host}/api/chat", data=data,
        headers={"Content-Type": "application/json"}, method="POST"
    )
    full = ""
    try:
        with urllib.request.urlopen(req, timeout=120) as resp:
            if stream:
                print(f"\n{BOLD}{RED}◆ SHADE{R} ", end="", flush=True)
                for line in resp:
                    line = line.decode().strip()
                    if not line:
                        continue
                    try:
                        chunk = json.loads(line)
                        tok = chunk.get("message", {}).get("content", "")
                        print(tok, end="", flush=True)
                        full += tok
                        if chunk.get("done"):
                            break
                    except json.JSONDecodeError:
                        continue
                print()
            else:
                raw  = json.loads(resp.read())
                full = raw.get("message", {}).get("content", "")
                print(f"\n{BOLD}{RED}◆ SHADE{R} {full}")
    except urllib.error.URLError as e:
        pe(f"Ollama error: {e}")
    except KeyboardInterrupt:
        print(f"\n{DIM}{WHT}[interrupted]{R}")
    return full

def ollama_chat_silent(host: str, model: str, messages: list, system: str = "") -> str:
    """Like ollama_chat but no streaming output — for file generation."""
    import urllib.request, urllib.error
    payload = {
        "model": model, "messages": messages, "stream": False,
        "options": {"num_gpu": 99 if detect_cuda() else 0},
    }
    if system:
        payload["system"] = system
    data = json.dumps(payload).encode()
    req  = urllib.request.Request(
        f"{host}/api/chat", data=data,
        headers={"Content-Type": "application/json"}, method="POST"
    )
    try:
        with urllib.request.urlopen(req, timeout=120) as resp:
            raw = json.loads(resp.read())
            return raw.get("message", {}).get("content", "")
    except Exception as e:
        pe(f"Ollama error: {e}")
        return ""
def strip_fences(text: str) -> str:
    """Remove all markdown code fences from LLM output."""
    lines = text.strip().splitlines()
    cleaned = [l for l in lines if not re.match(r'^\s*```[\w]*\s*$', l)]
    return "\n".join(cleaned).strip()

def llm_file_content(fname: str, request: str, cfg: dict) -> str:
    """Ask LLM to generate raw file content — silent, no streaming to screen."""
    raw = ollama_chat_silent(
        host=cfg["ollama_host"], model=cfg["model"],
        messages=[{"role": "user", "content":
            f"Generate content for a file named '{fname}'. "
            f"User request: {request}. "
            f"Output ONLY the raw file content. No explanations. No markdown. No fences."}],
        system="Output raw file content only. No markdown fences. No preamble. No explanation. Start directly with the code.",
    )
    return strip_fences(raw)

# ──────────────────────────────────────────────
# WEB SEARCH
# ──────────────────────────────────────────────
def search_searxng(q: str, host: str, n: int = 5) -> list:
    import urllib.request, urllib.parse
    params = urllib.parse.urlencode({"q": q, "format": "json", "categories": "general"})
    try:
        with urllib.request.urlopen(f"{host}/search?{params}", timeout=8) as r:
            data = json.loads(r.read())
            return [{"title": i.get("title",""), "url": i.get("url",""),
                     "snippet": i.get("content","")} for i in data.get("results",[])[:n]]
    except Exception as e:
        pw(f"SearXNG: {e}"); return []

def search_brave(q: str, key: str, n: int = 5) -> list:
    import urllib.request, urllib.parse
    params = urllib.parse.urlencode({"q": q, "count": n})
    req = urllib.request.Request(
        f"https://api.search.brave.com/res/v1/web/search?{params}",
        headers={"Accept": "application/json", "X-Subscription-Token": key}
    )
    try:
        with urllib.request.urlopen(req, timeout=8) as r:
            data = json.loads(r.read())
            return [{"title": i.get("title",""), "url": i.get("url",""),
                     "snippet": i.get("description","")}
                    for i in data.get("web",{}).get("results",[])[:n]]
    except Exception as e:
        pw(f"Brave: {e}"); return []

def do_search(q: str, cfg: dict) -> list:
    if cfg["search_engine"] == "searxng":
        return search_searxng(q, cfg["searxng_host"])
    return search_brave(q, cfg.get("brave_api_key",""))

def fmt_results(results: list) -> str:
    if not results: return "No results."
    return "\n\n".join(
        f"[{i}] {r['title']}\n    {r['url']}\n    {r['snippet']}"
        for i, r in enumerate(results, 1)
    )

def needs_web(q: str) -> bool:
    kw = ["latest","recent","current","today","news","cve-","vulnerability",
          "patch","release","update","exploit","2024","2025","poc","download"]
    return any(k in q.lower() for k in kw)

# ──────────────────────────────────────────────
# PYTHON-NATIVE FILE OPS
# ──────────────────────────────────────────────
def fs_create(path: str, content: str = "") -> bool:
    try:
        p = Path(path).expanduser().resolve()
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(content)
        file_track(str(p))
        po(f"Created → {BCYN}{p}{R}  ({len(content)} bytes)")
        return True
    except PermissionError:
        pw(f"Permission denied — retrying with sudo tee...")
        try:
            proc = subprocess.run(
                ["sudo", "tee", str(p)],
                input=content, text=True,
                capture_output=True
            )
            if proc.returncode == 0:
                file_track(str(p))
                po(f"Created → {BCYN}{p}{R}  ({len(content)} bytes)  {DIM}(via sudo){R}")
                return True
            else:
                pe(f"sudo tee failed: {proc.stderr.strip()}")
                return False
        except Exception as e:
            pe(f"Create failed: {e}"); return False
    except Exception as e:
        pe(f"Create failed: {e}"); return False

def fs_read(path: str) -> str | None:
    try:
        p = Path(path).expanduser()
        if not p.exists():
            pe(f"Not found: {p}"); return None
        return p.read_text()
    except Exception as e:
        pe(f"Read failed: {e}"); return None

def fs_delete(path: str) -> bool:
    try:
        p = Path(path).expanduser()
        # if not absolute, try relative to cwd first, then _last_file
        if not p.is_absolute():
            cwd_p = SHELL.cwd / p
            if cwd_p.exists():
                p = cwd_p
            elif _last_file and Path(_last_file).name == p.name:
                p = Path(_last_file)
        if not p.exists():
            pe(f"Not found: {p}"); return False
        c = input(f"{BYLW}[!]{R} Delete {p}? [y/N] ").strip().lower()
        if c != "y":
            pw("Aborted."); return False
        p.unlink()
        po(f"Deleted: {p}"); return True
    except Exception as e:
        pe(f"Delete failed: {e}"); return False

def fs_run(path: str, cfg: dict):
    p = Path(path).expanduser()
    if not p.exists():
        pe(f"Not found: {p}"); return
    ext = p.suffix
    cmd = f"python3 {p}" if ext == ".py" else f"bash {p}" if ext == ".sh" else str(p)
    run_shell(cmd, cfg=cfg)

def run_shell(cmd: str, use_sudo: bool = False, cfg: dict = None):
    SHELL.run(cmd, use_sudo=use_sudo, cfg=cfg)

# ──────────────────────────────────────────────
# SHELL STATE  (persistent cwd across commands)
# ──────────────────────────────────────────────
class ShellState:
    def __init__(self):
        self.cwd = Path.home()

    def chdir(self, path: str) -> bool:
        try:
            target = (self.cwd / Path(path).expanduser()).resolve()
            if not target.exists():
                pe(f"No such directory: {target}"); return False
            if not target.is_dir():
                pe(f"Not a directory: {target}"); return False
            self.cwd = target
            os.chdir(self.cwd)
            po(f"Now in: {BCYN}{self.cwd}{R}")
            return True
        except Exception as e:
            pe(f"cd failed: {e}"); return False

    def run(self, cmd: str, use_sudo: bool = False,
            cfg: dict = None, record: bool = True) -> tuple:
        """Run command in current cwd, capture + print output."""
        if use_sudo:
            if cfg and not cfg.get("sudo_allowed"):
                pw("Sudo disabled. Use /sudo enable"); return "", "", 1
            cmd = f"sudo {cmd}"
        pi(f"$ {BOLD}{cmd}{R}  {DIM}[{self.cwd}]{R}")
        r = subprocess.run(
            cmd, shell=True, capture_output=True, text=True, cwd=str(self.cwd)
        )
        out, err = r.stdout.rstrip(), r.stderr.rstrip()
        if out: print(f"{DIM}{WHT}{out}{R}")
        if err: print(f"{DIM}{RED}{err}{R}")
        if record:
            log(f"$ {cmd}  →  rc={r.returncode}")
        return out, err, r.returncode

SHELL = ShellState()

# ──────────────────────────────────────────────
# SYSTEM-LEVEL COMMANDS
# ──────────────────────────────────────────────
def detect_pkg_manager() -> str:
    for pm in ["apt", "dnf", "pacman", "zypper", "apk", "brew"]:
        if shutil.which(pm):
            return pm
    return "apt"  # fallback

def sys_install(packages: str, cfg: dict):
    """Auto-detect distro package manager and install."""
    pm = detect_pkg_manager()
    if pm == "apt":
        cmd = f"apt install -y {packages}"
    elif pm == "dnf":
        cmd = f"dnf install -y {packages}"
    elif pm == "pacman":
        cmd = f"pacman -S --noconfirm {packages}"
    elif pm == "zypper":
        cmd = f"zypper install -y {packages}"
    elif pm == "apk":
        cmd = f"apk add {packages}"
    else:
        cmd = f"{pm} install {packages}"
    SHELL.run(cmd, use_sudo=True, cfg=cfg)

def pip_install(packages: str, cfg: dict):
    SHELL.run(f"pip install {packages}", cfg=cfg)

# ──────────────────────────────────────────────
# INTENT DETECTION & HANDLING
# ──────────────────────────────────────────────
def parse_path_str(s: str) -> Path:
    """Resolve a path string relative to current shell cwd."""
    s = s.strip().strip("'\"")
    p = Path(s)
    if s.startswith("~"):
        return p.expanduser()
    if s.startswith("/"):
        return p
    # relative → resolve against cwd
    return (SHELL.cwd / p).resolve()

def extract_file_and_dir(prompt_lower: str) -> tuple[str, str]:
    pl = prompt_lower

    # direct absolute/home path with extension: "save it in /home/lio/deep.py"
    m = re.search(r'(?:to|in|into|at|save\s+in)\s+((?:/|~/?)[\w/.\-~]+\.[\w]+)', pl)
    if m:
        full = m.group(1)
        return Path(full).name, str(Path(full).parent)

    fname, direc = "", ""

    # filename: "named X" / "called X" / "file named X" / "file X.ext"
    mf = re.search(r'(?:named?|called)\s+["\']?([\w\-\.]+)["\']?', pl)
    if not mf:
        # bare filename with extension: "deep.py" / "hello.py"
        mf = re.search(r'\b([\w\-]+\.(?:py|sh|c|cpp|js|ts|rb|go|rs|java|html|css|md|txt|json|yaml))\b', pl)
    if mf:
        fname = mf.group(1)

    # directory
    md = re.search(r'(?:save.*?in|write.*?to|store.*?in|put.*?in|in|at|into|inside)\s+([~/][^\s,\.]+)', pl)
    if md:
        direc = md.group(1)

    # "this dir" / "current dir" / "here" / "we r in" → use cwd (empty direc)
    if re.search(r'\b(?:this\s+dir|current\s+dir|here|we\s+r\s+in|we\s+are\s+in|this\s+folder)\b', pl):
        direc = ""

    # if directory itself ends with the filename, split it
    if direc and fname and direc.endswith(fname):
        direc = str(Path(direc).parent)

    return fname, direc

def detect_intent(prompt: str, cfg: dict = None) -> dict | None:
    p  = prompt.strip()
    pl = p.lower()

    # ── resolve "it" / "that" pronouns to last file ──
    if _last_file and re.match(r'^(?:run|exec(?:ute)?|execute|delete|remove|open|read)\s+(?:it|that|the\s+file)[\s.!?]*$', pl):
        verb = pl.split()[0]
        path = _last_file
        if verb in ("run", "execute", "exec"):
            ext = Path(path).suffix.lower()
            runners = {".py":"python3",".sh":"bash",".js":"node",".rb":"ruby",".pl":"perl"}
            interp = runners.get(ext, "")
            cmd = f"{interp} {path}".strip() if interp else path
            return {"action": "shell_cmd", "cmd": cmd}
        if verb in ("delete", "remove"):
            return {"action": "delete", "path": path}
        if verb in ("open", "read"):
            return {"action": "read", "path": path}

    # ── "now delete the deep.py" / "delete deep.py" / "remove the X file" ──
    m = re.match(r'^(?:now\s+)?(?:delete|remove|rm)\s+(?:the\s+)?([\w.\-/~]+?)(?:\s+file)?[\s.!?]*$', pl)
    if m:
        return {"action": "delete", "path": m.group(1).strip()}

    # ── cd — catch all natural language navigation ──
    m = re.match(r'^(?:cd|change\s+(?:dir(?:ectory)?|to))\s+(.+)', pl)
    if m:
        return {"action": "cd", "path": m.group(1).strip()}

    # natural language: "take me to Downloads", "go to ~/Downloads", "open /tmp"
    m = re.search(
        r'(?:take\s+me\s+to|go\s+to|navigate\s+to|switch\s+to|move\s+to|jump\s+to)\s+'
        r'(?:the\s+)?(.+?)(?:\s+(?:dir(?:ectory)?|folder))?$',
        pl
    )
    if m:
        raw = m.group(1).strip()
        # resolve common named dirs
        NAMED = {
            "downloads": "~/Downloads", "desktop": "~/Desktop",
            "documents": "~/Documents", "home": "~",
            "root": "/root", "tmp": "/tmp", "etc": "/etc",
            "pictures": "~/Pictures", "videos": "~/Videos",
            "music": "~/Music", "projects": "~/projects",
        }
        path = NAMED.get(raw.lower().rstrip("/"), raw)
        if not re.search(r'\.(com|org|net|io|dev|app|html|co|uk)$', raw):
            return {"action": "cd", "path": path}

    # "open ~/Downloads" — only if it looks like a path not a browser target
    m = re.search(r'^open\s+(~/[\w.\-/]+|/[\w.\-/]+)', pl)
    if m:
        return {"action": "cd", "path": m.group(1).strip()}

    # ── pwd — catch all natural language variants ──
    if re.search(
        r'\b(?:pwd|'
        r'where\s+am\s+i|'
        r'what\s+dir|'
        r'which\s+dir(?:ectory)?|'
        r'current\s+dir|'
        r'current\s+folder|'
        r'current\s+path|'
        r'what\s+(?:is|\'s)\s+(?:my\s+|the\s+)?(?:current\s+)?(?:dir|directory|path|location|folder)'
        r')\b', pl
    ):
        return {"action": "pwd"}

    # ── ls — natural language list ──
    m = re.search(
        r'(?:^(?:ls|dir)(?:\s|$))'
        r'|(?:(?:list|show|what\'?s?\s+in|what\s+(?:files?|is)\s+in|contents?\s+of)'
        r'\s+(?:the\s+)?(?:files?|dir(?:ectory)?|folder)?'
        r'\s*(?:of\s+|in\s+|at\s+)?((?:~/|/|\./)[\w.\-/]*))',
        pl
    )
    if m:
        target = ""
        if m.lastindex and m.group(m.lastindex):
            target = m.group(m.lastindex).strip()
        # "we r in" / "i'm in" / "current" → no path, use cwd
        if re.search(r'\b(?:we\s+r|we\s+are|i\'?m|current|here|this)\b', pl):
            target = ""
        return {"action": "ls", "path": target}

    # ── mkdir ──
    m = re.search(r'(?:mkdir|make\s+(?:a\s+)?(?:new\s+)?dir(?:ectory)?|create\s+(?:a\s+)?(?:new\s+)?dir(?:ectory)?)\s+["\']?([~/\w.\-/]+)["\']?', pl)
    if m:
        return {"action": "mkdir", "path": m.group(1).strip()}

    # ── pip install ──
    m = re.search(r'(?:pip\s+install|install\s+(?:python\s+)?(?:package|library|module|dep(?:endenc(?:y|ies))?)\s+)([^\n,]+)', pl)
    if m:
        return {"action": "pip", "packages": m.group(1).strip()}

    # ── system install ──
    m = re.search(r'(?:install\s+(?!python)(?!pip))([^\n,]+?)(?:\s+(?:package|tool|utility|program))?$', pl)
    if m and not re.search(r'\b(?:file|script|named|called|\.py|\.sh)\b', pl):
        return {"action": "sysinstall", "packages": m.group(1).strip()}

    # ── wget ──
    m = re.search(r'(?:wget|download)\s+(https?://[^\s]+)', pl)
    if m:
        return {"action": "wget", "url": m.group(1)}

    # ── curl ──
    m = re.search(r'curl\s+(.*)', pl)
    if m:
        return {"action": "curl", "args": m.group(1).strip()}

    # ── run / execute file ──
    m = re.search(
        r'(?:run|exec(?:ute)?|launch|start)\s+'
        r'(?:the\s+|this\s+|my\s+)?'
        r'((?:~/|/|./)?[\w.\-/]*\.(?:py|sh|c|cpp|rb|js|ts|pl|go|rs|java|out|bin|elf))',
        pl
    )
    if m:
        return {"action": "run_file", "path": m.group(1).strip()}
    # bare filename with extension — "python3 exploit.py" style
    m = re.search(r'^(python3?|bash|sh|node|ruby|perl|gcc|g\+\+|cargo|go\s+run)\s+(.+)', pl)
    if m:
        return {"action": "shell_cmd", "cmd": p.strip()}

    # ── git clone ──
    m = re.search(r'(?:git\s+clone|clone)\s+(https?://[^\s]+|git@[^\s]+)', pl)
    if m:
        return {"action": "git_clone", "url": m.group(1)}

    # ── remember ──
    m = re.match(r'^(?:remember|note|store)\s+(?:that\s+)?(.+)', pl)
    if not m:
        m = re.match(r'^save\s+(?:that|this)[:\s]+(.+)', pl)
    if m and not re.search(r'\b(?:file|script|in\s+~/|in\s+/|\.py|\.sh|\.txt|\.md|named|called)\b', pl):
        content = p[m.start(1):].strip().strip("'\"")
        tag_m   = re.search(r'(?:tag|label)[:\s]+(\w+)', pl)
        return {"action":"remember","content":content,"tag":tag_m.group(1) if tag_m else "general"}

    # ── forget ──
    m = re.search(r'forget\s+(?:memory\s+)?#?(\d+)', pl)
    if m:
        return {"action":"forget","id":int(m.group(1))}

    # ── recall ──
    if re.search(r'(?:recall|show memories|list memories|what.*remember)', pl):
        q = re.sub(r'(?:recall|show memories?|list memories?|what do you remember)', '', pl).strip()
        return {"action":"recall","query":q}

    # ── edit / update existing file ──
    if re.search(r'\b(?:add|append|update|modify|edit|change|insert|fix|improve|refactor|rewrite)\b', pl):
        # look for a filename in the prompt
        fm = re.search(r'([\w.\-]+\.(?:py|sh|c|cpp|js|ts|rb|go|rs|java|html|css|md|txt|json|yaml|yml))', p)
        if fm:
            fname = fm.group(1)
            # find the file — check cwd first
            fpath = SHELL.cwd / fname
            if not fpath.exists():
                fpath = parse_path_str(fname)
            return {"action": "edit_file", "path": str(fpath), "request": p}

    # ── create file ──
    if re.search(r'\b(?:create|make|write|generate|touch|new\s+file)\b', pl):
        # don't fire if this is an edit request
        if not re.search(r'\b(?:add|append|update|modify|edit|change|insert|fix|improve)\b', pl):
            fname, direc = extract_file_and_dir(pl)
            # if no filename found, try to infer from context
            if not fname:
                ext_map = {"python":"py","bash":"sh","javascript":"js",
                           "c ":"c","c++":"cpp","ruby":"rb","go":"go"}
                for lang, ext in ext_map.items():
                    if lang in pl:
                        fname = f"script.{ext}"; break
                if not fname:
                    fname = "script.py"  # default
            fname = fname.rstrip(".,;:")
            fpath = (parse_path_str(direc) / fname) if direc else (SHELL.cwd / fname)
            # check if also wants to run it after
            run_after = bool(re.search(r'\b(?:exec(?:ute)?|run|execute)\b', pl))
            return {"action":"create","path":str(fpath),"original":p,"run_after":run_after}

    # ── delete ──
    m = re.search(r'(?:delete|remove|rm)\s+(?:file\s+)?([~/.\w\-/]+\.\w+)', pl)
    if m:
        return {"action":"delete","path":str(parse_path_str(m.group(1)))}

    # ── read ──
    m = re.search(r'(?:read|show|cat|display)\s+(?:file\s+|content\s+of\s+)?([~/.\w\-/]+\.\w+)', pl)
    if m:
        return {"action":"read","path":str(parse_path_str(m.group(1)))}

    # ── run file ──
    m = re.search(r'(?:run|execute|launch)\s+(?:file\s+)?([~/.\w\-/]+\.(?:py|sh|rb|js))', pl)
    if m:
        return {"action":"run","path":str(parse_path_str(m.group(1)))}

    # ── list SHADE-created files ──
    if re.search(r'(?:list|show)\s+(?:files?\s+(?:you\s+)?(?:created|made))', pl):
        return {"action":"list_files"}

    return None


def handle_intent(prompt: str, cfg: dict, history: list) -> bool:
    global _last_file
    intent = detect_intent(prompt, cfg)
    if not intent:
        return False

    a = intent["action"]

    # ── CD ──
    if a == "cd":
        SHELL.chdir(intent["path"])
        return True

    # ── PWD ──
    if a == "pwd":
        print(f"{BCYN}{SHELL.cwd}{R}")
        return True

    # ── LS ──
    if a == "ls":
        target = intent.get("path", "").strip()
        if target:
            tpath = parse_path_str(target)
        else:
            tpath = SHELL.cwd
        try:
            entries = sorted(tpath.iterdir(), key=lambda x: (not x.is_dir(), x.name.lower()))
            print(f"\n{DIM}{WHT}{tpath}{R}")
            print(f"{DIM}{'─'*50}{R}")
            for e in entries:
                if e.is_dir():
                    print(f"  {BBLU}📁 {e.name}/{R}")
                elif os.access(e, os.X_OK):
                    print(f"  {BGRN}⚡ {e.name}{R}")
                else:
                    size = e.stat().st_size
                    size_str = f"{size}B" if size < 1024 else f"{size//1024}K" if size < 1048576 else f"{size//1048576}M"
                    print(f"  {WHT}  {e.name}{R}  {DIM}{size_str}{R}")
            print(f"{DIM}{'─'*50}{R}  {DIM}{len(list(tpath.iterdir()))} items{R}\n")
        except PermissionError:
            pe(f"Permission denied: {tpath}")
        except Exception as e:
            pe(f"ls failed: {e}")
        return True

    # ── MKDIR ──
    if a == "mkdir":
        target = parse_path_str(intent["path"])
        try:
            target.mkdir(parents=True, exist_ok=True)
            po(f"Directory created: {BCYN}{target}{R}")
            file_track(str(target))
        except Exception as e:
            pe(f"mkdir failed: {e}")
        return True

    # ── PIP INSTALL ──
    if a == "pip":
        pip_install(intent["packages"], cfg)
        return True

    # ── SYSTEM INSTALL ──
    if a == "sysinstall":
        sys_install(intent["packages"], cfg)
        return True

    # ── WGET ──
    if a == "wget":
        SHELL.run(f"wget {intent['url']}", cfg=cfg)
        return True

    # ── CURL ──
    if a == "curl":
        SHELL.run(f"curl {intent['args']}", cfg=cfg)
        return True

    # ── GIT CLONE ──
    if a == "git_clone":
        SHELL.run(f"git clone {intent['url']}", cfg=cfg)
        return True

    # ── RUN FILE ──
    if a == "run_file":
        path = parse_path_str(intent["path"])
        if not path.exists():
            # try relative to cwd
            path = SHELL.cwd / intent["path"]
        if not path.exists():
            pe(f"File not found: {intent['path']}"); return True
        ext = path.suffix.lower()
        runners = {
            ".py":  f"python3 {path}",
            ".sh":  f"bash {path}",
            ".rb":  f"ruby {path}",
            ".js":  f"node {path}",
            ".pl":  f"perl {path}",
            ".go":  f"go run {path}",
            ".rs":  f"cargo run",
            ".c":   f"gcc {path} -o /tmp/_shade_out && /tmp/_shade_out",
            ".cpp": f"g++ {path} -o /tmp/_shade_out && /tmp/_shade_out",
            ".java":f"javac {path} && java {path.stem}",
            ".out": f"{path}",
            ".elf": f"{path}",
            ".bin": f"{path}",
        }
        cmd = runners.get(ext, f"chmod +x {path} && {path}")
        pi(f"Running: {BCYN}{cmd}{R}")
        SHELL.run(cmd, cfg=cfg)
        return True

    # ── SHELL CMD (direct interpreter prefix) ──
    if a == "shell_cmd":
        pi(f"Exec: {BCYN}{intent['cmd']}{R}")
        SHELL.run(intent["cmd"], cfg=cfg)
        return True

    # ── REMEMBER ──
    if a == "remember":
        mid = mem_save(intent["content"], tag=intent["tag"])
        po(f"Memory #{mid} saved  {DIM}[{intent['tag']}]{R}")
        history.append({"role":"user",      "content":prompt})
        history.append({"role":"assistant", "content":f"Saved to memory: {intent['content']}"})
        return True

    # ── FORGET ──
    if a == "forget":
        mem_delete(intent["id"])
        po(f"Memory #{intent['id']} deleted.")
        return True

    if a == "recall":
        q   = intent.get("query","").strip()
        mems = mem_search(q) if q else mem_list(20)
        if not mems:
            pi("Nothing stored yet.")
        else:
            print(f"\n{BOLD}{RED}◆ Memory{R}  {DIM}({len(mems)} entries){R}")
            print(f"{DIM}{'─'*52}{R}")
            for m in mems:
                print(f"  {DIM}#{m['id']:3}{R}  {BCYN}[{m['tag']}]{R}  {m['content']}")
                print(f"         {DIM}{m['ts']}  ·  {m['source']}{R}")
            print(f"{DIM}{'─'*52}{R}")
        return True

    if a == "list_files":
        files = files_list()
        if not files:
            pi("No files tracked yet.")
        else:
            print(f"\n{BOLD}{RED}◆ Files created by SHADE{R}")
            for f in files:
                ex = BGRN+"✓"+R if Path(f["path"]).exists() else BRED+"✗"+R
                print(f"  {ex} {BCYN}{f['path']}{R}  {DIM}{f['ts']}{R}")
        return True

    if a == "create":
        fpath = intent["path"]
        p     = Path(fpath).expanduser()
        pi(f"Creating: {BCYN}{p}{R}")
        if ollama_ok(cfg["ollama_host"]):
            pi("Generating content...")
            content = llm_file_content(p.name, intent["original"], cfg)
        else:
            content = f"# {p.name}\n# Created by SHADE\n"
            pw("Ollama offline — empty file created")
        fs_create(str(p), content)
        _last_file = str(p)
        po(f"Saved → {BCYN}{p}{R}")
        history.append({"role":"user",      "content":prompt})
        history.append({"role":"assistant", "content":f"Created {p}."})
        # auto-run if requested in the same prompt
        if intent.get("run_after"):
            ext = p.suffix.lower()
            runners = {".py":"python3",".sh":"bash",".js":"node",".rb":"ruby"}
            interp = runners.get(ext, "python3")
            pi(f"Executing: {BCYN}{interp} {p}{R}")
            SHELL.run(f"{interp} {p}", cfg=cfg)
        return True

    if a == "edit_file":
        fpath = Path(intent["path"]).expanduser()
        # if file doesn't exist, treat as create
        if not fpath.exists():
            pi(f"File not found — creating: {BCYN}{fpath}{R}")
            content = llm_file_content(fpath.name, intent["request"], cfg) if ollama_ok(cfg["ollama_host"]) else f"# {fpath.name}\n"
            fs_create(str(fpath), content)
            _last_file = str(fpath)
            po(f"Created → {BCYN}{fpath}{R}")
            return True
        existing = fpath.read_text()
        pi(f"Editing: {BCYN}{fpath}{R}")
        if ollama_ok(cfg["ollama_host"]):
            pi("Generating updated content...")
            updated = ollama_chat_silent(
                host=cfg["ollama_host"], model=cfg["model"],
                messages=[{"role":"user","content":
                    f"Here is the current content of {fpath.name}:\n```\n{existing}\n```\n\n"
                    f"User request: {intent['request']}\n\n"
                    f"Output ONLY the complete updated file content. No explanation. No fences."}],
                system="Output only raw file content. No markdown fences. No preamble. Start directly with the code.",
            )
            updated = strip_fences(updated)
            fs_create(str(fpath), updated)
            _last_file = str(fpath)
            po(f"Updated → {BCYN}{fpath}{R}")
            history.append({"role":"user",      "content":prompt})
            history.append({"role":"assistant", "content":f"Updated {fpath.name}."})
        else:
            pe("Ollama offline.")
        return True

    if a == "delete":
        fs_delete(intent["path"])
        return True

    if a == "read":
        content = fs_read(intent["path"])
        if content:
            print(f"\n{DIM}{WHT}{content}{R}")
            history.append({"role":"user",      "content":prompt})
            history.append({"role":"assistant", "content":f"[File:{intent['path']}]\n{content}"})
        return True

    if a == "run":
        fs_run(intent["path"], cfg)
        return True

    return False

# ──────────────────────────────────────────────
# SLASH COMMANDS
# ──────────────────────────────────────────────
# ──────────────────────────────────────────────
# LLM → BASH EXECUTOR
# ──────────────────────────────────────────────

SYSTEM_KEYWORDS = [
    "install","uninstall","remove package","update","upgrade",
    "kill","process","pid","port","netstat","ifconfig","ip addr",
    "disk","df ","du ","free ","memory","cpu","top","htop",
    "service","systemctl","journalctl","cron",
    "chmod","chown","chgrp","permission",
    "mount","umount","partition",
    "firewall","ufw","iptables",
    "user","group","passwd","useradd",
    "env","export",
    "what dir","which dir","current dir","where am i",
    "show me","list all","find all","search for",
    "how much space","how much memory","who is logged",
    "what is running","what processes","what's running",
    "what folder","what path","what location",
    # version queries
    "version of","what version","which version","installed version",
    "is installed","is it installed","do i have",
    "check if","what's the","whats the",
    # general system queries
    "how many","how do i check","what is my",
    "show all","list all","display all",
    "running on","installed on","available on",
]

def looks_like_system_task(prompt: str) -> bool:
    pl = prompt.lower().strip()
    # keyword match
    if any(kw in pl for kw in SYSTEM_KEYWORDS):
        return True
    # question word + system noun
    if re.search(r'\b(?:what|which|how|where|who|is|are|do|does|can)\b.{0,40}\b(?:version|installed|running|package|binary|command|tool|path|process|service|port|interface|device|driver|kernel|system|memory|cpu|gpu|disk|network|user|group|permission|file|dir|folder)\b', pl):
        return True
    # bare "<program> version" or "<program> --version"
    if re.search(r'\b\w+\s+(?:version|--version|-v)\b', pl):
        return True
    # "check X" / "get X" / "show X" / "find X"
    if re.search(r'\b(?:check|get|show|find|list|display)\s+\w', pl):
        return True
    return False

def llm_to_bash(prompt: str, cfg: dict) -> str | None:
    """Ask LLM to turn natural language into a bash command. Returns cmd or None."""
    ask = (
        f'The user said: "{prompt}"\n'
        f"Current directory: {SHELL.cwd}\n\n"
        f"Convert this into a single bash command to execute on Linux.\n"
        f"Reply with ONLY the raw bash command, one line, no markdown, no fences, no explanation.\n"
        f"If this is NOT a system/shell task, reply with exactly: NOTASYSTASK"
    )
    raw = ollama_chat(
        host=cfg["ollama_host"], model=cfg["model"],
        messages=[{"role": "user", "content": ask}],
        stream=False,
        system="Output only a raw bash command or NOTASYSTASK. No markdown. No explanation.",
    )
    raw = strip_fences(raw)
    if not raw or "NOTASYSTASK" in raw.upper() or "\n" in raw.strip():
        return None
    return raw

def try_exec_as_bash(prompt: str, cfg: dict, history: list) -> bool:
    """Classify prompt → get bash from LLM → execute → return True if handled."""
    if not looks_like_system_task(prompt):
        return False
    if not ollama_ok(cfg["ollama_host"]):
        return False

    pi(f"{DIM}Routing as system command...{R}")
    cmd = llm_to_bash(prompt, cfg)
    if not cmd:
        return False

    # safety check for destructive commands
    destructive = any(w in cmd for w in ["rm -rf","dd ","mkfs","shutdown","reboot",":(){ :|:& };:"])
    if destructive:
        c = input(f"{BRED}[!]{R} Destructive command detected: {BOLD}{cmd}{R}\n    Run anyway? [y/N] ").strip().lower()
        if c != "y":
            pw("Aborted."); return True

    out, err, rc = SHELL.run(cmd, cfg=cfg)

    summary = f"Ran: `{cmd}`\n"
    if out: summary += f"Output:\n{out}\n"
    if err: summary += f"Stderr:\n{err}\n"
    summary += f"Exit: {rc}"

    history.append({"role":"user",      "content": prompt})
    history.append({"role":"assistant", "content": summary})
    return True


# ──────────────────────────────────────────────
# SLASH COMMANDS
# ──────────────────────────────────────────────
def handle_slash(line: str, cfg: dict, history: list) -> bool:
    parts = line.strip().split(None, 2)
    cmd   = parts[0].lower()

    if cmd == "/help":
        print(f"""
{BOLD}{RED}SHADE Commands{R}
{DIM}{'─'*52}{R}
  {BCYN}/help{R}                    This menu
  {BCYN}/clear{R}                   Clear screen
  {BCYN}/status{R}                  System info
  {BCYN}/model [name]{R}            Switch model
  {BCYN}/models{R}                  List models
  {BCYN}/run <cmd>{R}               Run shell command
  {BCYN}/sudo enable|disable{R}     Toggle sudo
  {BCYN}/sudo <cmd>{R}              Sudo command
  {BCYN}/read <file>{R}             Load file into context
  {BCYN}/write <file>{R}            Save last response to file
  {BCYN}/search <query>{R}          Web search
  {BCYN}/mem [query]{R}             List/search memories
  {BCYN}/mem-del <id>{R}            Delete a memory
  {BCYN}/files{R}                   List files SHADE created
  {BCYN}/history{R}                 Conversation history
  {BCYN}/clear-history{R}           Wipe history
  {BCYN}/config{R}                  Show config
  {BCYN}/set <key> <val>{R}         Set config value
  {BCYN}/exit{R}                    Quit
{DIM}{'─'*52}{R}
  Natural language:
    {BYLW}remember that my target IP is 10.0.0.1{R}
    {BYLW}create a file called shell.py in ~/tools{R}
    {BYLW}recall{R} · {BYLW}forget #3{R}
    {BYLW}!nmap -sV 10.0.0.1{R}  ← direct shell
""")
        return True

    elif cmd == "/clear":
        os.system("clear"); return True

    elif cmd in ("/exit", "/quit"):
        print(f"\n{DIM}{RED}Fading into the shadows...{R}\n"); sys.exit(0)

    elif cmd == "/status":
        olm  = ollama_ok(cfg["ollama_host"])
        cuda = detect_cuda()
        mc   = len(mem_list(9999))
        print(f"""
{BOLD}{RED}◆ SHADE Status{R}
{DIM}{'─'*48}{R}
  Network   : {(BGRN+"ONLINE") if check_network() else (BRED+"OFFLINE")}{R}
  Ollama    : {(BGRN+"RUNNING") if olm else (BRED+"DOWN")}{R}
  Model     : {BCYN}{cfg['model']}{R}
  GPU       : {(BGRN+gpu_info()) if cuda else (DIM+WHT+"CPU only")}{R}
  Sudo      : {(BGRN+"enabled") if cfg['sudo_allowed'] else (DIM+WHT+"disabled")}{R}
  Search    : {BCYN}{cfg['search_engine']}{R}
  Memories  : {BCYN}{mc}{R} stored
  DB        : {BCYN}{DB_FILE}{R}
{DIM}{'─'*48}{R}""")
        return True

    elif cmd == "/models":
        ms = ollama_models(cfg["ollama_host"])
        if ms:
            print(f"\n{BOLD}{RED}Models:{R}")
            for m in ms:
                d = BGRN+"●"+R if m==cfg["model"] else DIM+WHT+"○"+R
                print(f"  {d} {m}")
        else:
            pw("Ollama not running or no models.")
        return True

    elif cmd == "/model":
        if len(parts) < 2: pi(f"Current: {BCYN}{cfg['model']}{R}")
        else:
            cfg["model"] = parts[1]; save_config(cfg)
            po(f"Model → {BCYN}{cfg['model']}{R}")
        return True

    elif cmd == "/sudo":
        if len(parts) < 2:
            pi("sudo: " + ("enabled" if cfg["sudo_allowed"] else "disabled"))
        elif parts[1] == "enable":
            c = input(f"{BRED}[!]{R} Grant SHADE sudo? [y/N] ").strip().lower()
            if c == "y":
                cfg["sudo_allowed"] = True; save_config(cfg); po("Sudo enabled.")
        elif parts[1] == "disable":
            cfg["sudo_allowed"] = False; save_config(cfg); po("Sudo disabled.")
        else:
            run_shell(" ".join(parts[1:]), use_sudo=True, cfg=cfg)
        return True

    elif cmd == "/run":
        if len(parts) < 2: pw("Usage: /run <cmd>")
        else: run_shell(" ".join(parts[1:]), cfg=cfg)
        return True

    elif cmd == "/read":
        if len(parts) < 2: pw("Usage: /read <file>")
        else:
            c = fs_read(parts[1])
            if c:
                print(f"{DIM}{WHT}{c[:1000]}{'...' if len(c)>1000 else ''}{R}")
                history.append({"role":"user","content":f"[File:{parts[1]}]\n{c}"})
                po(f"Loaded ({len(c)} chars)")
        return True

    elif cmd == "/write":
        if len(parts) < 2: pw("Usage: /write <file>")
        else:
            last = next((m["content"] for m in reversed(history) if m["role"]=="assistant"), None)
            if last: fs_create(parts[1], last)
            else: pw("No AI response in history.")
        return True

    elif cmd == "/search":
        if len(parts) < 2: pw("Usage: /search <query>")
        else:
            if not check_network(): pw("No network."); return True
            q = " ".join(parts[1:])
            pi(f"Searching: {q}")
            print(fmt_results(do_search(q, cfg)))
        return True

    elif cmd == "/mem":
        q    = " ".join(parts[1:]) if len(parts) > 1 else ""
        mems = mem_search(q) if q else mem_list(20)
        if not mems:
            pi("Nothing stored.")
        else:
            print(f"\n{BOLD}{RED}◆ Memory{R}  {DIM}({len(mems)}){R}")
            print(f"{DIM}{'─'*52}{R}")
            for m in mems:
                print(f"  {DIM}#{m['id']:3}{R}  {BCYN}[{m['tag']}]{R}  {m['content']}")
                print(f"         {DIM}{m['ts']}{R}")
            print(f"{DIM}{'─'*52}{R}")
        return True

    elif cmd == "/mem-del":
        if len(parts) < 2: pw("Usage: /mem-del <id>")
        else:
            mem_delete(int(parts[1])); po(f"Memory #{parts[1]} deleted.")
        return True

    elif cmd == "/files":
        files = files_list()
        if not files: pi("No files tracked.")
        else:
            print(f"\n{BOLD}{RED}◆ SHADE-created Files{R}")
            for f in files:
                ex = BGRN+"✓"+R if Path(f["path"]).exists() else BRED+"✗"+R
                print(f"  {ex} {BCYN}{f['path']}{R}  {DIM}{f['ts']}{R}")
        return True

    elif cmd == "/history":
        if not history: pi("Empty.")
        else:
            print(f"\n{BOLD}{RED}History{R}")
            for i, m in enumerate(history[-10:], 1):
                role = f"{BCYN}you{R}" if m["role"]=="user" else f"{BOLD}{RED}SHADE{R}"
                snip = m["content"][:80].replace("\n"," ")
                print(f"  {DIM}{i:2}.{R} {role}: {snip}{'…' if len(m['content'])>80 else ''}")
        return True

    elif cmd == "/clear-history":
        history.clear(); po("History cleared."); return True

    elif cmd == "/config":
        print(f"\n{BOLD}{RED}Config{R}")
        for k, v in cfg.items():
            val = "***" if "key" in k.lower() and v else str(v)
            print(f"  {BCYN}{k:22}{R} {val}")
        return True

    elif cmd == "/set":
        if len(parts) < 3: pw("Usage: /set <key> <value>")
        else:
            k, v = parts[1], parts[2]
            if k not in cfg: pw(f"Unknown: {k}")
            else:
                if isinstance(cfg[k], bool):  cfg[k] = v.lower() in ("true","1","yes")
                elif isinstance(cfg[k], int): cfg[k] = int(v)
                else: cfg[k] = v
                save_config(cfg); po(f"{k} = {cfg[k]}")
        return True

    return False

# ──────────────────────────────────────────────
# READLINE
# ──────────────────────────────────────────────
def setup_readline():
    try: readline.read_history_file(str(HIST_FILE))
    except FileNotFoundError: pass
    readline.set_history_length(500)
    atexit.register(readline.write_history_file, str(HIST_FILE))
    cmds = ["/help","/clear","/exit","/model","/models","/run","/sudo",
            "/read","/write","/search","/status","/history","/clear-history",
            "/config","/set","/mem","/mem-del","/files"]
    def comp(text, state):
        opts = [c for c in cmds if c.startswith(text)]
        return opts[state] if state < len(opts) else None
    readline.set_completer(comp)
    readline.parse_and_bind("tab: complete")

# ──────────────────────────────────────────────
# MAIN
# ──────────────────────────────────────────────
def main():
    args = parse_args()
    os.system("clear")
    print(SAMURAI)
    print(BANNER)

    cfg     = load_config()
    history = []
    setup_readline()

    if args.model:
        cfg["model"] = args.model

    online = check_network()
    cuda   = detect_cuda()
    olm    = ollama_ok(cfg["ollama_host"])

    print(f"  {DIM}Network:{R}  {(BGRN+'ONLINE'+R) if online else (BRED+'OFFLINE'+R)}"
          f"   {DIM}GPU:{R} {(BGRN+'CUDA'+R) if cuda else (DIM+'CPU'+R)}"
          f"   {DIM}Ollama:{R} {(BGRN+'READY'+R) if olm else (BRED+'DOWN'+R)}")
    print(f"  {DIM}Model:{R}    {BCYN}{cfg['model']}{R}")
    mc = len(mem_list(9999))
    if mc:
        print(f"  {DIM}Memory:{R}   {BCYN}{mc}{R} {DIM}stored entries{R}")

    # voice setup
    voice_queue: queue.Queue = queue.Queue()
    voice_listener = None
    if args.lt:
        if check_stt_deps():
            voice_listener = VoiceListener(
                voice_queue,
                model_size=args.whisper_model,
                wake_word=args.wake_word,
                thresh=args.thresh,
            )
            voice_listener.start()
            print(f"  {DIM}Mode:{R}     {BGRN}LISTEN + TEXT{R}  {DIM}(speak or type){R}")
        else:
            pw("STT deps missing."); install_stt_deps()
            print(f"  {DIM}Mode:{R}     {BYLW}TEXT ONLY{R}")
    else:
        print(f"  {DIM}Mode:{R}     {BCYN}TEXT{R}  {DIM}(shade --lt to add voice){R}")

    print(f"  {DIM}Type {BCYN}/help{R}{DIM} for commands.{R}\n")

    if not olm:
        pw("Ollama not running → ollama serve")
        pw("Pull model         → ollama pull qwen2.5-coder:7b\n")

    def sys_prompt():
        base = cfg["system_prompt"] + "\n\n" + sys_header()
        ctx  = mem_context()
        return base + ("\n\n" + ctx if ctx else "")

    def process_prompt(prompt: str, source: str = "text"):
        if source == "voice":
            cwd_s = str(SHELL.cwd).replace(str(Path.home()), "~")
            print(f"\n{BOLD}{RED}[SHADE]{R}{DIM}:{BCYN}{cwd_s}{R}{DIM}›{R} {DIM}[🎤]{R} {prompt}")
        if not prompt:
            return
        # shell shortcut
        if prompt.startswith("!"):
            sc = prompt[1:].strip()
            sudo = sc.startswith("sudo ")
            if sudo: sc = sc[5:]
            run_shell(sc, use_sudo=sudo, cfg=cfg); return
        # slash
        if prompt.startswith("/"):
            if prompt.strip() == "/stop": stop_media(); return
            handle_slash(prompt, cfg, history); return
        # media + browser
        if handle_media_browser(prompt, history, cfg): return
        # file / memory
        if handle_intent(prompt, cfg, history): return
        # LLM → bash
        if try_exec_as_bash(prompt, cfg, history): return
        # LLM conversation
        if not ollama_ok(cfg["ollama_host"]):
            pe("Ollama offline."); pi("Start: ollama serve"); return
        user_content = prompt
        if online and needs_web(prompt):
            pi(f"{DIM}Fetching web context...{R}")
            results = do_search(prompt, cfg)
            if results:
                user_content += "\n[Web context]\n" + fmt_results(results)
        history.append({"role": "user", "content": user_content})
        response = ollama_chat(
            host=cfg["ollama_host"], model=cfg["model"],
            messages=history[-cfg["max_history"]:],
            stream=cfg["stream"], system=sys_prompt(),
        )
        if response:
            history.append({"role": "assistant", "content": response})
            log(f"[{source}] {prompt[:80]}")
            log(f"shade: {response[:80]}")
            code_blocks = re.findall(r"```(?:\w+)?\n(.*?)```", response, re.DOTALL)
            if code_blocks:
                print(f"{DIM}{WHT}[{len(code_blocks)} code block(s) — /write <file> to save]{R}")

    while True:
        # drain voice queue first
        if args.lt:
            while not voice_queue.empty():
                try:
                    _, text = voice_queue.get_nowait()
                    process_prompt(text, source="voice")
                except queue.Empty:
                    break
        try:
            cwd_short = str(SHELL.cwd).replace(str(Path.home()), "~")
            prompt = input(f"{BOLD}{RED}[SHADE]{R}{DIM}:{BCYN}{cwd_short}{R}{DIM}›{R} ").strip()
        except (EOFError, KeyboardInterrupt):
            if voice_listener: voice_listener.stop()
            stop_media()
            print(f"\n{DIM}{RED}Fading into the shadows...{R}\n"); break
        if not prompt:
            continue
        process_prompt(prompt, source="text")

# ──────────────────────────────────────────────
# BROWSER  (xdg-open)
# ──────────────────────────────────────────────
def get_browser() -> str | None:
    for b in ["firefox", "google-chrome", "chromium", "chromium-browser", "brave-browser"]:
        if shutil.which(b):
            return b
    return None

def get_or_ask_browser(cfg: dict) -> str | None:
    b = cfg.get("browser") or get_browser()
    if b:
        return b
    print(f"\n{BYLW}[!]{R} No browser found automatically.")
    name = input(f"{BCYN}[?]{R} Type your browser command (e.g. firefox): ").strip()
    if name:
        cfg["browser"] = name
        save_config(cfg)
        po(f"Saved: {name}")
        return name
    return None

def launch_browser(browser: str, url: str = ""):
    """Launch browser exactly like typing it in terminal — nohup + disown."""
    cmd = f"nohup {browser}"
    if url:
        cmd += f" '{url}'"
    cmd += " >/dev/null 2>&1 &"
    os.system(cmd)

# ──────────────────────────────────────────────
# YOUTUBE / MEDIA  (yt-dlp + mpv, streaming)
# ──────────────────────────────────────────────

# Global mpv process handle so we can stop it
_mpv_proc: subprocess.Popen | None = None
_last_file: str = ""   # tracks last file created/edited for "run it" / "delete it"

def yt_search_url(query: str) -> str | None:
    """Use yt-dlp to find the first YouTube result URL."""
    if not shutil.which("yt-dlp"):
        pe("yt-dlp not found. Install: pip install yt-dlp"); return None
    try:
        r = subprocess.run(
            ["yt-dlp", "--no-playlist", "--get-url",
             f"ytsearch1:{query}", "--format", "bestaudio/best"],
            capture_output=True, text=True, timeout=20
        )
        url = r.stdout.strip().splitlines()[0] if r.stdout.strip() else None
        return url
    except Exception as e:
        pe(f"yt-dlp search failed: {e}"); return None

def yt_search_page_url(query: str) -> str | None:
    """Get the actual YouTube page URL (for opening in browser)."""
    if not shutil.which("yt-dlp"):
        pe("yt-dlp not found."); return None
    try:
        r = subprocess.run(
            ["yt-dlp", "--no-playlist", "--get-id", f"ytsearch1:{query}"],
            capture_output=True, text=True, timeout=20
        )
        vid_id = r.stdout.strip().splitlines()[0] if r.stdout.strip() else None
        return f"https://www.youtube.com/watch?v={vid_id}" if vid_id else None
    except Exception as e:
        pe(f"yt-dlp ID lookup failed: {e}"); return None

def play_youtube(query: str):
    """Stream YouTube audio/video via yt-dlp piped to mpv."""
    global _mpv_proc
    if not shutil.which("mpv"):
        pe("mpv not found. Install: sudo apt install mpv"); return
    if not shutil.which("yt-dlp"):
        pe("yt-dlp not found. Install: pip install yt-dlp"); return

    # stop any currently playing media
    stop_media()

    pi(f"Searching YouTube: {BCYN}{query}{R}")
    _mpv_proc = subprocess.Popen(
        ["mpv", "--no-video", f"ytdl://ytsearch1:{query}",
         "--ytdl-format=bestaudio/best", "--really-quiet", "--title=SHADE Media"],
        stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL
    )
    po(f"Playing: {BCYN}{query}{R}  {DIM}(mpv streaming){R}")
    pi(f"Stop with: {BCYN}stop music{R} or {BCYN}/stop{R}")

def play_local(path: str):
    """Play a local media file with mpv."""
    global _mpv_proc
    p = Path(path).expanduser()
    if not p.exists():
        pe(f"File not found: {p}"); return
    if not shutil.which("mpv"):
        pe("mpv not found. Install: sudo apt install mpv"); return
    stop_media()
    _mpv_proc = subprocess.Popen(
        ["mpv", "--really-quiet", str(p)],
        stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL
    )
    po(f"Playing: {BCYN}{p}{R}")

def stop_media():
    """Kill any running mpv instance."""
    global _mpv_proc
    if _mpv_proc and _mpv_proc.poll() is None:
        _mpv_proc.terminate()
        _mpv_proc = None
        po("Playback stopped.")

# ──────────────────────────────────────────────
# MEDIA + BROWSER INTENT DETECTION
# ──────────────────────────────────────────────
def detect_media_browser_intent(prompt: str) -> dict | None:
    pl = prompt.lower().strip()

    # ── open specific sites by name ──
    KNOWN_SITES = {
        "youtube":    "https://www.youtube.com",
        "github":     "https://github.com",
        "google":     "https://www.google.com",
        "reddit":     "https://www.reddit.com",
        "twitter":    "https://www.twitter.com",
        "x":          "https://www.x.com",
        "instagram":  "https://www.instagram.com",
        "linkedin":   "https://www.linkedin.com",
        "gmail":      "https://mail.google.com",
        "stackoverflow": "https://stackoverflow.com",
        "hackernews": "https://news.ycombinator.com",
        "wikipedia":  "https://www.wikipedia.org",
        "chatgpt":    "https://chat.openai.com",
        "claude":     "https://claude.ai",
    }
    m = re.match(r'^(?:open|launch|go to|visit|show)\s+(?:the\s+)?(\w+)[\s.!?]*$', pl)
    if m:
        site = m.group(1).lower()
        if site in KNOWN_SITES:
            return {"action": "open_url", "url": KNOWN_SITES[site]}

    # ── bare browser open ──
    if re.match(r'^(?:open|launch|start)\s+(?:the\s+)?(?:browser|chrome|firefox|web|internet|edge|opera)[\s.!?]*$', pl):
        return {"action": "open_browser"}

    # ── open URL directly ──
    m = re.search(r'(?:open|launch|go to|visit|browse to?)\s+(https?://[^\s]+|(?:www\.)?[\w\-]+\.(?:com|org|net|io|dev|sh|co|uk|in|app)[^\s]*)', pl)
    if m:
        return {"action": "open_url", "url": m.group(1)}

    # ── browser search ──
    m = re.search(r'(?:search\s+(?:for\s+)?|google\s+|look\s+up\s+|browse\s+(?:for\s+)?)(.+?)(?:\s+(?:in|on|using)\s+(?:browser|chrome|firefox|google|duckduckgo))?$', pl)
    if m and re.search(r'\b(?:search|google|look\s+up|browse)\b', pl):
        q = m.group(1).strip()
        engine = "duckduckgo" if "duck" in pl else "google"
        return {"action": "browser_search", "query": q, "engine": engine}

    # ── play youtube / song ──
    m = re.search(r'(?:play|stream|put\s+on|queue)\s+(.+?)(?:\s+(?:on\s+youtube|on\s+spotify|music|song|video))?$', pl)
    if m and re.search(r'\b(?:play|stream|put\s+on|queue)\b', pl):
        q = m.group(1).strip()
        if re.search(r'[~/].*\.\w{2,4}$', q):
            return {"action": "play_local", "path": q}
        return {"action": "play_youtube", "query": q}

    # ── open youtube search in browser ──
    m = re.search(r'(?:search|find|look\s+up)\s+(.+?)\s+(?:on\s+)?youtube', pl)
    if m:
        return {"action": "open_youtube", "query": m.group(1).strip()}

    # ── open youtube video (play in browser) ──
    m = re.search(r'(?:open|show|watch)\s+(.+?)\s+(?:on\s+)?(?:youtube|yt)', pl)
    if m:
        return {"action": "open_youtube", "query": m.group(1).strip()}

    # ── stop media ──
    if re.search(r'\b(?:stop|pause|quit|kill)\s+(?:music|media|song|video|audio|mpv|playback|playing)\b', pl):
        return {"action": "stop_media"}

    return None

def handle_media_browser(prompt: str, history: list, cfg: dict = None) -> bool:
    cfg = cfg or {}
    intent = detect_media_browser_intent(prompt)
    if not intent:
        return False

    a = intent["action"]

    if a == "open_browser":
        browser = get_or_ask_browser(cfg)
        if browser:
            pi(f"Launching {browser}...")
            launch_browser(browser)
            po(f"{browser} launched.")
        return True

    if a == "open_url":
        url = intent["url"]
        if not url.startswith("http"):
            url = "https://" + url
        browser = get_or_ask_browser(cfg)
        if browser:
            pi(f"Opening: {BCYN}{url}{R}")
            launch_browser(browser, url)
            po("Done.")
        history.append({"role":"user",      "content": prompt})
        history.append({"role":"assistant", "content": f"Opened {url}."})
        return True

    if a == "browser_search":
        import urllib.parse
        base = ("https://duckduckgo.com/?q=" if intent.get("engine") == "duckduckgo"
                else "https://www.google.com/search?q=")
        url  = base + urllib.parse.quote_plus(intent["query"])
        browser = get_or_ask_browser(cfg)
        if browser:
            pi(f"Searching: {BCYN}{intent['query']}{R}")
            launch_browser(browser, url)
            po("Done.")
        history.append({"role":"user",      "content": prompt})
        history.append({"role":"assistant", "content": f"Searched '{intent['query']}'."})
        return True

    if a == "play_youtube":
        play_youtube(intent["query"])
        history.append({"role":"user",      "content": prompt})
        history.append({"role":"assistant", "content": f"Streaming '{intent['query']}' via mpv."})
        return True

    if a == "play_local":
        play_local(intent["path"])
        return True

    if a == "open_youtube":
        import urllib.parse
        query = intent["query"]
        pi(f"Finding YouTube link for: {BCYN}{query}{R}")
        url = None
        if ollama_ok(cfg["ollama_host"]):
            raw = ollama_chat(
                host=cfg["ollama_host"], model=cfg["model"],
                messages=[{"role":"user","content":
                    f"Give me only the YouTube search URL for: {query}\n"
                    f"Format: https://www.youtube.com/results?search_query=...\n"
                    f"Reply with the URL only, nothing else."}],
                stream=False,
                system="Output only a single URL. No explanation. No markdown.",
            )
            raw = raw.strip().strip("'\"")
            if raw.startswith("https://www.youtube.com"):
                url = raw
        if not url:
            url = "https://www.youtube.com/results?search_query=" + urllib.parse.quote_plus(query)
        browser = get_or_ask_browser(cfg)
        if browser:
            pi(f"Opening: {BCYN}{url}{R}")
            launch_browser(browser, url)
            po("Done.")
        history.append({"role":"user",      "content": prompt})
        history.append({"role":"assistant", "content": f"Opened YouTube for '{query}'."})
        return True

    if a == "stop_media":
        stop_media()
        return True

    return False

# ──────────────────────────────────────────────
# SPEECH TO TEXT  (faster-whisper, optional)
# ──────────────────────────────────────────────
STT_AVAILABLE = False

def check_stt_deps() -> bool:
    """Check if STT dependencies are installed."""
    try:
        import pyaudio       # noqa
        import faster_whisper # noqa
        return True
    except ImportError:
        return False

def install_stt_deps():
    """Offer to install STT dependencies."""
    print(f"\n{BYLW}[!]{R} Speech-to-text requires:")
    print(f"    {DIM}pip install faster-whisper pyaudio{R}")
    print(f"    {DIM}sudo apt install portaudio19-dev{R}  (for pyaudio)\n")
    c = input(f"{BCYN}[?]{R} Install now? [y/N] ").strip().lower()
    if c == "y":
        SHELL.run("sudo apt install -y portaudio19-dev", use_sudo=False)
        SHELL.run("pip install faster-whisper pyaudio --break-system-packages")
        po("Dependencies installed. Restart SHADE with --lt to use voice.")
    else:
        pw("Skipping STT install. Running in text-only mode.")

class VoiceListener:
    """
    Two-phase voice listener:
      Phase 1 — STANDBY: tiny Whisper watches for wake word (low resource)
      Phase 2 — ACTIVE:  full model transcribes the actual command

    Wake word: "hey shade" (configurable)
    Visual indicator shows current state in terminal.
    """
    WAKE_WORDS = [
        # intended
        "hey shade", "hey shad", "shade", "hey chad", "a shade",
        "hey shadow", "hey shades", "shade.", "hey!", "hey,",
        # whisper tiny commonly mishears "hey shade" as these:
        "thank you", "thank you thank you", "thanks",
        "hey chade", "hey chaed", "hey shaped", "hey shaid",
        "a shad", "ashade", "hey said", "hey stayed",
        "hey state", "hey sayed", "hey spade",
        "data", "datasets", "hey space",
        "hate shade", "hate shad",
    ]

    def __init__(self, prompt_queue: queue.Queue,
                 model_size: str = "base",
                 wake_word: str = "hey shade",
                 thresh: int = 500):
        self.q          = prompt_queue
        self.model_size = model_size
        self.wake_word  = wake_word.lower()
        self.thresh     = thresh
        self.running    = False
        self._thread    = None
        self.model      = None
        self.wake_model = None
        self.state      = "standby"

    def _is_wake_word(self, text: str) -> bool:
        t = text.lower().strip().rstrip(".,!?")
        if not t:
            return False
        # any variant present
        for w in self.WAKE_WORDS:
            if w in t:
                return True
        # starts with hey or shade
        if t.startswith("hey") or t.startswith("shade"):
            return True
        # single word that sounds close — levenshtein-lite
        words = t.split()
        for word in words:
            if word in ("shade", "shad", "shadow", "chad", "hey"):
                return True
        return False

    def _load_models(self):
        from faster_whisper import WhisperModel
        cuda = detect_cuda()

        # Always run Whisper on CPU — leave all VRAM for Ollama
        # CPU tiny/base is fast enough for STT, Ollama needs the GPU more
        device  = "cpu"
        compute = "int8"

        if cuda:
            pi(f"CUDA available but reserving for Ollama — Whisper on CPU")

        cmd_model = self.model_size if self.model_size != "base" else "base"

        pi(f"Loading Whisper tiny  {DIM}(wake word / cpu){R}")
        self.wake_model = WhisperModel("tiny", device="cpu", compute_type="int8")
        po(f"Wake model ready  {DIM}(tiny/cpu){R}")

        pi(f"Loading Whisper {cmd_model}  {DIM}(commands / cpu){R}")
        self.model = WhisperModel(cmd_model, device="cpu", compute_type="int8")
        po(f"Command model ready  {DIM}({cmd_model}/cpu){R}")

    def _amp(self, data: bytes) -> int:
        return max(
            abs(int.from_bytes(data[i:i+2], 'little', signed=True))
            for i in range(0, len(data)-1, 2)
        )

    def _record_chunk(self, stream, rate: int, chunk: int,
                      max_dur: float, silence_dur: float) -> list[bytes]:
        """Record audio until silence or max_dur reached."""
        frames     = []
        silent_for = 0.0
        total      = 0

        while self.running and total < int(rate / chunk * max_dur):
            data = stream.read(chunk, exception_on_overflow=False)
            frames.append(data)
            total += 1
            amp = self._amp(data)
            if amp < self.thresh:
                silent_for += chunk / rate
                if silent_for >= silence_dur:
                    break
            else:
                silent_for = 0.0
        return frames

    def _to_wav(self, frames: list[bytes], pa, rate: int) -> str:
        import pyaudio, wave, struct, array
        path = tempfile.mktemp(suffix=".wav")

        raw = b"".join(frames)

        # resample to 16000 if needed — Whisper requires 16000Hz
        if rate != 16000:
            samples = array.array('h', raw)
            ratio   = 16000 / rate
            new_len = int(len(samples) * ratio)
            resampled = array.array('h', (
                samples[min(int(i / ratio), len(samples)-1)]
                for i in range(new_len)
            ))
            raw  = resampled.tobytes()
            rate = 16000

        with wave.open(path, 'wb') as wf:
            wf.setnchannels(1)
            wf.setsampwidth(pa.get_sample_size(pyaudio.paInt16))
            wf.setframerate(rate)
            wf.writeframes(raw)
        return path

    def _transcribe(self, model, wav_path: str) -> str:
        segs, _ = model.transcribe(wav_path, beam_size=5, language="en")
        return " ".join(s.text for s in segs).strip().lower()

    def _is_wake_word(self, text: str) -> bool:
        t = text.lower().strip().rstrip(".,!?")
        # exact list match
        for w in self.WAKE_WORDS:
            if w in t:
                return True
        # configurable wake word
        if self.wake_word.lower() in t:
            return True
        # loose: any word starting with "sh" after "hey"
        if re.search(r'\bhey\s+sh\w*', t):
            return True
        # loose: standalone "shade" anywhere
        if re.search(r'\bsha?d\w*\b', t):
            return True
        return False

    def _set_state(self, state: str):
        self.state = state
        if state == "active":
            # visual cue — print indicator without disrupting prompt
            print(f"\r{BOLD}{RED}[SHADE]{R}{BRED} ● LISTENING...{R}          ", flush=True)
        else:
            print(f"\r{BOLD}{RED}[SHADE]{R}{DIM} ○ standby{R}               ", flush=True)

    def _listen_loop(self):
        import pyaudio, wave

        CHUNK        = 1024
        WAKE_DUR     = 2.5
        WAKE_SIL     = 0.6
        CMD_DUR      = 12.0
        CMD_SIL      = 2.0   # wait 2s of silence before cutting off

        # suppress ALSA spam and create PyAudio
        devnull    = os.open(os.devnull, os.O_WRONLY)
        old_stderr = os.dup(2)
        os.dup2(devnull, 2)
        pa = pyaudio.PyAudio()
        os.dup2(old_stderr, 2)
        os.close(devnull)
        os.close(old_stderr)

        # PipeWire hides devices from PyAudio enumeration on some systems
        # Try known working indices first (from stt_test output), then scan
        dev_idx     = None
        native_rate = 44100

        # probe candidate indices — pipewire is usually 7,8,9 on KDE systems
        candidates = list(range(pa.get_device_count())) or list(range(15))
        # put high indices first as pipewire tends to be last
        candidates = sorted(candidates, reverse=True)

        for i in candidates:
            try:
                info = pa.get_device_info_by_index(i)
                if int(info.get("maxInputChannels", 0)) > 0:
                    # verify it actually opens
                    devnull_t = os.open(os.devnull, os.O_WRONLY)
                    old_err_t = os.dup(2); os.dup2(devnull_t, 2)
                    try:
                        _t = pa.open(format=pyaudio.paInt16, channels=1,
                                     rate=int(info["defaultSampleRate"]),
                                     input=True, input_device_index=i,
                                     frames_per_buffer=CHUNK)
                        _t.close()
                        dev_idx     = i
                        native_rate = int(info["defaultSampleRate"])
                        os.dup2(old_err_t, 2); os.close(devnull_t); os.close(old_err_t)
                        break
                    except OSError:
                        os.dup2(old_err_t, 2); os.close(devnull_t); os.close(old_err_t)
                        continue
            except Exception:
                continue

        if dev_idx is None:
            pe("PyAudio cannot open any input device.")
            pe("Fix: run 'shade --lt' as your normal user (not root/sudo)")
            pe("Or run: pipewire-pulse & before starting shade")
            return

        dev_name = pa.get_device_info_by_index(dev_idx)['name'][:40]
        pi(f"Audio device [{dev_idx}]: {dev_name}  {DIM}({native_rate}Hz){R}")

        # try 16000Hz, fall back to native rate
        RATE = 16000
        try:
            devnull2 = os.open(os.devnull, os.O_WRONLY)
            old_err2 = os.dup(2); os.dup2(devnull2, 2)
            _check = pa.open(format=pyaudio.paInt16, channels=1, rate=RATE,
                             input=True, input_device_index=dev_idx,
                             frames_per_buffer=CHUNK)
            os.dup2(old_err2, 2); os.close(devnull2); os.close(old_err2)
            _check.close()
        except OSError:
            try: os.dup2(old_err2, 2); os.close(devnull2); os.close(old_err2)
            except Exception: pass
            RATE = native_rate
            pw(f"Using {RATE}Hz (resampling to 16000 for Whisper)")

        stream = pa.open(format=pyaudio.paInt16, channels=1, rate=RATE,
                         input=True, input_device_index=dev_idx,
                         frames_per_buffer=CHUNK)

        self._set_state("standby")
        _dbg_counter = 0  # print amplitude every N chunks to confirm mic is working

        while self.running:
            # ── PHASE 1: wait for sound above threshold ──
            triggered = False
            pre_frames = []
            while self.running:
                data = stream.read(CHUNK, exception_on_overflow=False)
                amp  = self._amp(data)
                # debug: print amplitude every ~2 seconds so user can confirm mic works
                _dbg_counter += 1
                if _dbg_counter % int(RATE / CHUNK * 2) == 0:
                    bar = "█" * min(20, amp // 200)
                    print(f"\r{DIM}[mic: {amp:5} {bar:<20}]{R}  ", end="", flush=True)
                if amp > self.thresh:
                    pre_frames.append(data)
                    triggered = True
                    break

            if not triggered:
                continue

            # ── record short clip to check wake word ──
            frames = pre_frames + self._record_chunk(
                stream, RATE, CHUNK, WAKE_DUR, WAKE_SIL
            )

            wav = self._to_wav(frames, pa, RATE)
            try:
                text = self._transcribe(self.wake_model, wav)
                log(f"[wake check] heard: {text}")
                # show what was heard in dim text so user can debug
                print(f"\r{DIM}[heard: {text[:50]}]{R}          ", flush=True)
            except Exception as e:
                log(f"Wake transcribe error: {e}")
                text = ""
            finally:
                os.unlink(wav)

            if not self._is_wake_word(text):
                # not wake word — ignore and stay in standby
                continue

            # ── PHASE 2: wake word detected ──
            wake_frames = frames  # save in case user said command in same breath
            self._set_state("active")

            # record command — start immediately, include any trailing wake audio
            cmd_frames = self._record_chunk(
                stream, RATE, CHUNK, CMD_DUR, CMD_SIL
            )

            self._set_state("standby")

            # combine wake + command frames so "hey shade list files" works in one breath
            all_frames = wake_frames + cmd_frames

            if not all_frames:
                continue

            wav2 = self._to_wav(all_frames, pa, RATE)
            try:
                cmd_text = self._transcribe(self.model, wav2)
                # always print what was heard for feedback
                print(f"\r{BCYN}[🎤 heard]{R} {cmd_text or '(empty)'}          ", flush=True)
                if cmd_text and len(cmd_text) > 2:
                    # strip wake word prefix if present
                    clean = cmd_text.lower().strip()
                    for w in self.WAKE_WORDS + [self.wake_word.lower()]:
                        if clean.startswith(w):
                            clean = clean[len(w):].strip(" ,.")
                            break
                    if clean and len(clean) > 1:
                        self.q.put(("voice", clean))
                    elif cmd_text and len(cmd_text) > 2:
                        self.q.put(("voice", cmd_text))
            except Exception as e:
                log(f"Command transcribe error: {e}")
                print(f"\r{RED}[stt error]{R} {e}", flush=True)
            finally:
                os.unlink(wav2)

        stream.stop_stream()
        stream.close()
        pa.terminate()

    def start(self):
        self._load_models()
        self.running = True
        self._thread = threading.Thread(target=self._listen_loop, daemon=True)
        self._thread.start()
        print(f"\n  {DIM}Wake word:{R}  {BOLD}{RED}\"{self.wake_word}\"{R}")
        po(f"Voice ready  {DIM}(say \"{self.wake_word}\" to activate){R}\n")

    def stop(self):
        self.running = False

# ──────────────────────────────────────────────
# ARG PARSING
# ──────────────────────────────────────────────
def parse_args():
    parser = argparse.ArgumentParser(
        prog="shade",
        description="SHADE — Shadow Intelligence for Linux"
    )
    parser.add_argument(
        "--lt", action="store_true",
        help="Listen + Text mode: voice input alongside typing"
    )
    parser.add_argument(
        "--whisper-model", default="base",
        choices=["tiny","base","small","medium","large","large-v2","large-v3"],
        help="Whisper model for commands (default: base, auto-upgrades to medium on CUDA)"
    )
    parser.add_argument(
        "--wake-word", default="hey shade",
        help="Wake word phrase (default: 'hey shade')"
    )
    parser.add_argument(
        "--thresh", type=int, default=500,
        help="Mic amplitude threshold 100-3000 (default: 500). Lower = more sensitive."
    )
    parser.add_argument(
        "--model", default=None,
        help="Override Ollama model"
    )
    return parser.parse_args()





if __name__ == "__main__":
    main()

