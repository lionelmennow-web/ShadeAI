#!/usr/bin/env bash
# ─────────────────────────────────────────────────────────────
#  SHADE — Full Installer (includes all features)
#  Detects OS, installs all dependencies
# ─────────────────────────────────────────────────────────────

set -e

RED='\033[91m'; GRN='\033[92m'; YLW='\033[93m'
CYN='\033[96m'; DIM='\033[2m';  R='\033[0m'; BOLD='\033[1m'

info()  { echo -e "${CYN}[i]${R} $*"; }
ok()    { echo -e "${GRN}[+]${R} $*"; }
warn()  { echo -e "${YLW}[!]${R} $*"; }
err()   { echo -e "${RED}[x]${R} $*"; exit 1; }

echo -e "${BOLD}${RED}"
cat << 'BANNER'
███████╗██╗  ██╗ █████╗ ██████╗ ███████╗
██╔════╝██║  ██║██╔══██╗██╔══██╗██╔════╝
███████╗███████║███████║██║  ██║█████╗  
╚════██║██╔══██║██╔══██║██║  ██║██╔══╝  
███████║██║  ██║██║  ██║██████╔╝███████╗
╚══════╝╚═╝  ╚═╝╚═╝  ╚═╝╚═════╝ ╚══════╝
BANNER
echo -e "${R}${DIM}       SHADE Full Installer${R}"
echo ""

# ── Detect OS & Package Manager ────────────────────────────
detect_os() {
    if [ -f /etc/os-release ]; then
        . /etc/os-release
        OS_ID="${ID,,}"
        OS_NAME="$PRETTY_NAME"
    elif [ "$(uname)" = "Darwin" ]; then
        OS_ID="darwin"; OS_NAME="macOS"
    else
        OS_ID="unknown"; OS_NAME="Unknown"
    fi

    if   command -v pacman  &>/dev/null; then PKG="pacman";  INSTALL="sudo pacman -S --noconfirm"; UPDATE="sudo pacman -Sy"
    elif command -v dnf     &>/dev/null; then PKG="dnf";     INSTALL="sudo dnf install -y";        UPDATE="sudo dnf check-update || true"
    elif command -v zypper  &>/dev/null; then PKG="zypper";  INSTALL="sudo zypper install -y";     UPDATE="sudo zypper refresh"
    elif command -v apk     &>/dev/null; then PKG="apk";     INSTALL="sudo apk add";               UPDATE="sudo apk update"
    elif command -v apt     &>/dev/null; then PKG="apt";     INSTALL="sudo apt install -y";        UPDATE="sudo apt update"
    elif command -v brew    &>/dev/null; then PKG="brew";    INSTALL="brew install";               UPDATE="brew update"
    else PKG="unknown"; INSTALL="echo Install manually:"; UPDATE=""; fi

    info "Detected: ${CYN}$OS_NAME${R}  (pkg manager: ${CYN}$PKG${R})"
}
detect_os

# ── Python 3 ───────────────────────────────────────────────
info "Checking Python 3..."
if ! command -v python3 &>/dev/null; then
    warn "Python 3 not found — installing..."
    $INSTALL python3
fi
PY_VER=$(python3 -c "import sys; print(f'{sys.version_info.major}.{sys.version_info.minor}')")
ok "Python $PY_VER"
if ! python3 -c "import sys; sys.exit(0 if sys.version_info >= (3,10) else 1)" 2>/dev/null; then
    warn "Python 3.10+ recommended (you have $PY_VER). Proceeding anyway."
fi

# ── pip ────────────────────────────────────────────────────
info "Checking pip..."
if ! python3 -m pip --version &>/dev/null; then
    $INSTALL python3-pip 2>/dev/null || python3 -m ensurepip --upgrade
fi
ok "pip ready"

# ── Ollama ─────────────────────────────────────────────────
info "Checking Ollama..."
if command -v ollama &>/dev/null; then
    ok "Ollama already installed"
else
    info "Installing Ollama..."
    if [ "$OS_ID" = "darwin" ] && command -v brew &>/dev/null; then
        brew install ollama
    else
        curl -fsSL https://ollama.ai/install.sh | sh
    fi
    ok "Ollama installed"
fi

# Start Ollama if not running
if ! curl -s http://localhost:11434/api/tags &>/dev/null; then
    info "Starting Ollama..."
    if command -v systemctl &>/dev/null && systemctl list-unit-files ollama.service &>/dev/null 2>&1; then
        sudo systemctl enable --now ollama 2>/dev/null
    else
        nohup ollama serve >/dev/null 2>&1 &
    fi
    sleep 3
fi

# ── Pull model ─────────────────────────────────────────────
echo ""
info "Choose a model:"
echo -e "  ${CYN}1${R}) qwen2.5-coder:1.5b  ${DIM}~1GB   fast, great for CPU${R}"
echo -e "  ${CYN}2${R}) qwen2.5-coder:7b    ${DIM}~4GB   balanced  (recommended)${R}"
echo -e "  ${CYN}3${R}) qwen2.5-coder:14b   ${DIM}~8GB   best quality, needs GPU${R}"
echo -e "  ${CYN}4${R}) Skip"
echo ""
read -r -p "$(echo -e "${CYN}[?]${R} Choose [1-4, default=1]: ")" choice
choice="${choice:-1}"
DEFAULT_MODEL="qwen2.5-coder:1.5b"
case "$choice" in
    1) ollama pull qwen2.5-coder:1.5b  && DEFAULT_MODEL="qwen2.5-coder:1.5b" ;;
    2) ollama pull qwen2.5-coder:7b    && DEFAULT_MODEL="qwen2.5-coder:7b" ;;
    3) ollama pull qwen2.5-coder:14b   && DEFAULT_MODEL="qwen2.5-coder:14b" ;;
    4) warn "Skipped. Pull later: ollama pull qwen2.5-coder:1.5b" ;;
    *) ollama pull qwen2.5-coder:1.5b  && DEFAULT_MODEL="qwen2.5-coder:1.5b" ;;
esac

# ── System dependencies ────────────────────────────────────
echo ""
info "Installing system dependencies..."

# git
if ! command -v git &>/dev/null; then
    $INSTALL git && ok "git installed"
fi

# curl
if ! command -v curl &>/dev/null; then
    $INSTALL curl && ok "curl installed"
fi

# gcc / g++ for compiling C/C++ files
if ! command -v gcc &>/dev/null; then
    if [ "$PKG" = "pacman" ]; then
        sudo pacman -S --noconfirm base-devel
    elif [ "$PKG" = "brew" ]; then
        xcode-select --install 2>/dev/null || true
    else
        $INSTALL build-essential 2>/dev/null || $INSTALL gcc g++
    fi
    ok "gcc/g++ installed"
else
    ok "gcc already installed"
fi

# ── Audio deps (for the hidden feature 👀) ─────────────────
echo ""
info "Installing audio support..."
if [ "$PKG" = "pacman" ]; then
    sudo pacman -S --noconfirm portaudio python-pyaudio 2>/dev/null || \
    sudo pacman -S --noconfirm portaudio && \
    pip3 install pyaudio --break-system-packages 2>/dev/null || true
elif [ "$PKG" = "brew" ]; then
    brew install portaudio
    pip3 install pyaudio 2>/dev/null || true
elif [ "$PKG" = "dnf" ]; then
    sudo dnf install -y portaudio portaudio-devel python3-pyaudio 2>/dev/null || \
    sudo dnf install -y portaudio portaudio-devel && \
    pip3 install pyaudio --break-system-packages 2>/dev/null || true
elif [ "$PKG" = "zypper" ]; then
    sudo zypper install -y portaudio-devel && \
    pip3 install pyaudio --break-system-packages 2>/dev/null || true
else
    # apt/debian default
    sudo apt install -y portaudio19-dev python3-pyaudio 2>/dev/null || \
    sudo apt install -y portaudio19-dev && \
    pip3 install pyaudio --break-system-packages 2>/dev/null || true
fi
ok "Audio support installed"

# ── Python packages ────────────────────────────────────────
echo ""
info "Installing Python packages..."

PIP_FLAGS="--break-system-packages --quiet"

# core
pip3 install $PIP_FLAGS requests 2>/dev/null || pip3 install --quiet requests

# faster-whisper (for the hidden feature 👀)
info "Installing faster-whisper..."
pip3 install $PIP_FLAGS faster-whisper 2>/dev/null || pip3 install --quiet faster-whisper
ok "faster-whisper installed"

# yt-dlp for media
info "Installing yt-dlp..."
pip3 install $PIP_FLAGS yt-dlp 2>/dev/null || pip3 install --quiet yt-dlp
ok "yt-dlp installed"

ok "All Python packages ready"

# ── mpv ────────────────────────────────────────────────────
echo ""
read -r -p "$(echo -e "${CYN}[?]${R} Install mpv for media playback? [Y/n]: ")" ans
ans="${ans:-Y}"
if [[ "${ans,,}" =~ ^y ]]; then
    if [ "$PKG" = "pacman" ]; then
        sudo pacman -S --noconfirm mpv
    elif [ "$PKG" = "brew" ]; then
        brew install mpv
    else
        $INSTALL mpv 2>/dev/null || warn "mpv not found in repos — install manually"
    fi
    ok "mpv installed"
fi

# ── CUDA check ─────────────────────────────────────────────
echo ""
info "Checking GPU..."
if command -v nvidia-smi &>/dev/null && nvidia-smi &>/dev/null 2>&1; then
    GPU=$(nvidia-smi --query-gpu=name --format=csv,noheader 2>/dev/null | head -1)
    ok "CUDA GPU detected: ${CYN}$GPU${R}"
    info "Ollama + Whisper will use GPU automatically"
    # install CUDA-capable torch for faster-whisper if not present
    info "Checking CUDA torch for faster-whisper..."
    python3 -c "import torch; assert torch.cuda.is_available()" 2>/dev/null && \
        ok "CUDA torch already present" || \
        pip3 install $PIP_FLAGS torch --index-url https://download.pytorch.org/whl/cu121 2>/dev/null && \
        ok "CUDA torch installed" || \
        warn "Could not install CUDA torch — Whisper will fall back to CPU"
else
    warn "No NVIDIA GPU — everything runs on CPU"
    info "Still works great. Use qwen2.5-coder:1.5b for best CPU speed."
fi

# ── Install SHADE ──────────────────────────────────────────
echo ""
info "Installing SHADE..."

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
if [ -f "$SCRIPT_DIR/shade.py" ]; then
    SHADE_SRC="$SCRIPT_DIR/shade.py"
else
    err "shade.py not found. Run install.sh from the shade directory."
fi

sudo cp "$SHADE_SRC" /usr/local/bin/shade
sudo chmod +x /usr/local/bin/shade
ok "SHADE installed → /usr/local/bin/shade"

# ── Write config ───────────────────────────────────────────
mkdir -p "$HOME/.shade"
if [ ! -f "$HOME/.shade/config.json" ]; then
cat > "$HOME/.shade/config.json" << CFGEOF
{
  "model": "$DEFAULT_MODEL",
  "ollama_host": "http://localhost:11434",
  "stream": true,
  "max_history": 20,
  "searxng_host": "http://localhost:8080",
  "browser": ""
}
CFGEOF
    ok "Config written: ~/.shade/config.json"
fi

# ── Done ───────────────────────────────────────────────────
echo ""
echo -e "${BOLD}${GRN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${R}"
echo -e "${BOLD}${GRN}  SHADE installed successfully!${R}"
echo -e "${BOLD}${GRN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${R}"
echo ""
echo -e "  Start SHADE:       ${CYN}shade${R}"
echo -e "  Switch model:      ${CYN}shade --model qwen2.5-coder:7b${R}"
echo -e "  Help:              ${CYN}/help${R}  (inside SHADE)"
echo -e "  Status:            ${CYN}/status${R}  (inside SHADE)"
echo ""
echo -e "  ${DIM}Data stored in:    ~/.shade/${R}"
echo -e "  ${DIM}Logs:              ~/.shade/shade.log${R}"
echo ""
echo -e "  ${DIM}Tip: read the README for hidden features 👀${R}"
echo ""
